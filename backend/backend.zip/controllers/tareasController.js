const supabase = require("../db");


const crearTarea = async (req, res) => {
  try {
    const { titulo, descripcion, fecha_entrega, creador_id,instrucciones,nota_maxima,grupo} = req.body;

    if (!titulo || !creador_id) {
      return res.status(400).json({
        error: "Titulo y creador_id son obligatorios",
      });
    }

    const { data: usuario, error: errorUsuario } = await supabase
      .from("usuarios")
      .select("rol")
      .eq("id", creador_id)
      .single();

    if (errorUsuario || !usuario) {
      return res.status(404).json({
        error: "Usuario no encontrado",
      });
    }

    if (usuario.rol !== "docente") {
      return res.status(403).json({
        error: "Solo docentes pueden crear tareas",
      });
    }

    // 🟢 insertar tarea
    const { data, error } = await supabase
      .from("tareas")
      .insert([
        {
          titulo,
          descripcion,
          fecha_entrega,
          creador_id,
          instrucciones,
          nota_maxima,
          grupo
        },
      ])
      .select();

    if (error) throw error;

    res.status(201).json({
      mensaje: "Tarea creada correctamente",
      tarea: data[0],
    });

  } catch (error) {
    res.status(500).json({
      error: error.message,
    });
  }
};

// 🟢 Obtener tareas (con usuario)
const obtenerTareas = async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("tareas")
      .select("id,titulo,descripcion,fecha_entrega,instrucciones,nota_maxima,grupo,estado,usuarios(nombre,email)");
    if (error) throw error;

    res.json(data);

  } catch (error) {
    res.status(500).json({
      error: error.message,
    });
  }
};


//Cambiar estado de una tarea
const cambiarEstadoTarea = async (req, res) => {
  try {
    const { id } = req.params;
    const { estado } = req.body;

    if (!estado) {
      return res.status(400).json({
        error: "El estado es obligatorio"
      });
    }

    const { data, error } = await supabase
      .from("tareas")
      .update({ estado })
      .eq("id", id)
      .select();

    if (error) throw error;

    return res.json({
      mensaje: "Estado actualizado correctamente",
      tarea: data[0]
    });
  } catch (error) {
    return res.status(500).json({
      error: error.message
    });
  }
};


module.exports = {
  crearTarea,
  obtenerTareas,
  cambiarEstadoTarea
};